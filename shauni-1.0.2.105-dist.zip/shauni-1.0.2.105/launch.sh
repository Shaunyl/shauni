java -cp lib/*:. -jar lib/database-1.0.1.127.jar
